import java.util.ArrayList;
import java.util.HashMap;
import java.util.Scanner;

public class CafeProgram {


	
	static double totalPrice = 0;
	static double totalTax;
	static double totalTaxPrice;
	
	public void addToTot (double singelPrice) {
		totalPrice += singelPrice;
	}
	
 //\\///\\\//\\//\\//\\//\\//\\////\\///\\\//\\//\\//\\//\\//\\////\\///\\\//\\//\\//\\//\\//\\////\\///\\\//\\//\\//\\//\\//\\////\\///\\\//\\//\\//\\//\\//\\//
//\\///\\\//\\//\\//\\//\\//\\////\\///\\\//\\//\\//\\//\\//\\////\\///\\\//\\//\\//\\//\\//\\////\\///\\\//\\//\\//\\//\\//\\////\\///\\\//\\//\\//\\//\\//\\//
	public static void main(String[] args) {
		CafeProgram myOrder = new CafeProgram();
		Scanner sc = new Scanner(System.in);
		
		//Drink menu
		HashMap<String, Double> drinkMenu = new HashMap <String, Double>();
		drinkMenu.put("Pepsi", 2.30);
		drinkMenu.put("Coffe", 0.0);
		drinkMenu.put("Water", 0.50);
		drinkMenu.put("Juice", 1.20);
		drinkMenu.put("Cocoa", 1.20);
		
		//Food menu
		HashMap<String, Double> foodMenu = new HashMap <String, Double>();
		foodMenu.put("Salad", 1.70);
		foodMenu.put("Pasta", 4.90);
		foodMenu.put("Pizza", 6.30);
		foodMenu.put("Toast", 2.30);
		foodMenu.put("Fries", 1.40);
		
		//Dessert Menu
		HashMap<String, Double> dessertMenu = new HashMap <String, Double>();
		dessertMenu.put("Fudge", 1.40);
		dessertMenu.put("Cakes", 1.10);
		dessertMenu.put("Mocha", 2.10);
		dessertMenu.put("Donut", 0.60);
		
		//Coffee Menu
		HashMap<String, Double> coffeeMenu = new HashMap <String, Double>();
		coffeeMenu.put("MacchiatoS", 2.40);
		coffeeMenu.put("MacchiatoL", 3.10);
		coffeeMenu.put("Macchiatoo", 3.20);
		coffeeMenu.put("Riistretto", 2.70);
		coffeeMenu.put("Long Black", 1.50);
		coffeeMenu.put("Café Latte", 1.60);
		coffeeMenu.put("Cappuccino", 1.50);
		coffeeMenu.put("Flat White", 1.30);
		
		ArrayList<String> order = new ArrayList<String>();
		
		//Console
		System.out.println("Hello, welcome to our cafe, how many are you?");
		int user_in = sc.nextInt();
		System.out.println("A table for " + user_in + " then!");
		System.out.println("Lets get your order - please have a look at the menu:" );
		System.out.println("  +-----------------+");
		System.out.println("  |       Drinks:   |" );
		for ( String drink : drinkMenu.keySet() ) {
			System.out.println("  |  " + drink + " -- " + drinkMenu.get(drink) + "$" + "  |");
			if (drink == "Cocoa") {
				System.out.println("  |       Food:     |");
			}
		}
		for ( String food : foodMenu.keySet() ) {
			System.out.println("  |  " + food + " -- " + foodMenu.get(food) + "$" + "  |");
			if (food == "Salad") {
				System.out.println("  |     Desserts:   |");
			}
	}
		for ( String des : dessertMenu.keySet() ) {
			System.out.println("  |  " + des + " -- " + dessertMenu.get(des) + "$" + "  |");

	}
	//Coffee menu asker
		System.out.println("  +-----------------+");
		System.out.println("Would you like to check our coffee menu?(Y or N)");
		char user_coffeeMenu = sc.next().charAt(0);
		if (user_coffeeMenu == 'Y') {
			System.out.println("  +----------------------+");
			System.out.println("  |       Coffee:        |");
			for ( String coffee : coffeeMenu.keySet() ) {
				System.out.println("  |  " + coffee + " -- " + coffeeMenu.get(coffee) + "$" + "  |");
			}	
			System.out.println("  +----------------------+");
		}
		
	//Order System
		System.out.println("Please place your order below, press enter when you are done with your order");
		   Scanner scanner=new Scanner(System.in);
		    while (true) {
		        System.out.println("Enter order:");
		        String user_order = scanner.nextLine();
		        order.add(user_order);
		        for (String key : drinkMenu.keySet()) {
		        	if (key.equals(user_order)) {
		        		System.out.println("-Order recorded-");
		        		myOrder.addToTot(drinkMenu.get(key));
		        	}
        				
        }
		        for (String key : foodMenu.keySet()) {
		        	if (key.equals(user_order)) {
		        		System.out.println("-Order recorded-");
		        		myOrder.addToTot(foodMenu.get(key));
		        	}
        				
        }
		        for (String key : dessertMenu.keySet()) {
		        	if (key.equals(user_order)) {
		        		System.out.println("-Order recorded-");
		        		myOrder.addToTot(dessertMenu.get(key));
		        	}
        				
        }
		        for (String key : coffeeMenu.keySet()) {
		        	if (key.equals(user_order)) {
		        		System.out.println("-Order recorded-");
		        		myOrder.addToTot(coffeeMenu.get(key));
		        	}
        				
        }
		        if(user_order.equals("")){
		            break;
		            
		        }
		        
		        	
		        }
		    System.out.println("Thank you for placing your order, here is your receipt:");
		    //Receipt
		    System.out.println("-------------------");
		    System.out.println("     Receipt");
		    System.out.println("  -Customer Copy-");
		    System.out.println();
 //System.out.println(order);//test
		    double totalTax = totalPrice * 0.1;
			double totalTaxPrice = totalPrice + totalTax;
			System.out.println("   Sub total: " + Math.round(totalPrice) + "$"); 
			System.out.println("   Sales Tax: " + Math.round(totalTax) + "$");
			System.out.println("            =======");
			System.out.println("      Total:   " + Math.round(totalTaxPrice) + "$");
			System.out.println();
			System.out.println("--------------------------");
			System.out.println("    Please choose:");
			System.out.println("    payment method");
			System.out.println("  Credit/PayPal/Cash");
			
			String user_payment = scanner.nextLine();
			if (user_payment.equals("Credit")) {
				System.out.println(" Credit card number: ");
				int user_paymentCredit = sc.nextInt();
				System.out.println("  Payment recived from");
				System.out.println("  credit number: "+ user_paymentCredit);
			}else if(user_payment.equals("PayPal")) {
				System.out.println("  PayPal number: ");
				int user_paymentCredit = sc.nextInt();
				System.out.println("  Payment recived from");
				System.out.println("  PayPal number: "+ user_paymentCredit);
			}else {
				System.out.println("  Dont forget to pay");
				System.out.println("    before leaving");
				
			}
			System.out.println("  Please sign your name:");
			String user_name = scanner.nextLine();
			System.out.println("  Have a nice day " + user_name + ",");
			System.out.println("    thank you for choosing");
			System.out.println("         Java Caffee");
			System.out.println();
			
//System.out.println("Payment Method");
		    }


		
}